from pathlib import Path
import json
import sys

import pandas as pd
import streamlit as st
import torch
from PIL import Image

BASE_DIR = Path(__file__).resolve().parent
SRC_DIR = BASE_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

st.set_page_config(page_title="GALAXAI | Galaxy Morphology", page_icon="🌌", layout="wide")
st.markdown("""
<style>
.stApp {background:radial-gradient(circle at 10% 0%,#18213a 0,transparent 35%),#080b14}
.block-container {max-width:1450px;padding-top:1.5rem}
.hero {padding:1.6rem 1.8rem;border:1px solid #304064;border-radius:22px;background:linear-gradient(125deg,#1c2c50,#0d1122);margin-bottom:1.2rem}
.eyebrow {color:#a7bbff;letter-spacing:.15em;font-size:.75rem;font-weight:700}
.hero h1 {color:#f3f5ff;font-size:2.8rem;margin:.35rem 0}
.hero p {color:#c5cde4;max-width:950px}
div[data-testid="stMetric"] {background:#151d31;border:1px solid #2a3858;padding:12px;border-radius:13px}
</style>
<div class="hero"><div class="eyebrow">HUBBLE SPACE TELESCOPE · RESEARCH PROTOTYPE</div>
<h1>🌌 GALAXAI</h1><p>Deep learning-based multi-attribute galaxy morphology analysis.
Explore the three CNN architectures, compare held-out test metrics, inspect confusion matrices,
and run image inference.</p></div>
""", unsafe_allow_html=True)

BINARY = ["featured", "edge_on", "bar", "spiral_arms", "disturbed", "merger", "clumpy", "symmetry"]
MULTI = ["bulge", "roundedness"]
TASKS = BINARY + MULTI
LABELS = {
    "featured":"Featured", "edge_on":"Edge-on", "bar":"Bar", "spiral_arms":"Spiral arms",
    "disturbed":"Disturbed", "merger":"Merger", "clumpy":"Clumpy", "symmetry":"Symmetry",
    "bulge":"Bulge prominence", "roundedness":"Roundedness",
}
CLASSES = {"bulge":["None","Just noticeable","Obvious","Dominant"],
           "roundedness":["Completely rounded","In-between","Cigar-shaped"]}
MODELS = {
    "Model 1 — Custom CNN V2": {
        "architecture":"Custom CNN V2", "description":"Four convolutional blocks (32, 64, 128, 256 channels), adaptive pooling, and a shared 256-unit head.",
        "metrics":[BASE_DIR/"models/model1_custom_cnn/results/test_metrics.json", BASE_DIR/"results/model1_v2/test_metrics.json"],
        "heatmaps":BASE_DIR/"models/model1_custom_cnn/results", "best_epoch":27, "parameters":"1,242,863",
        "checkpoint":BASE_DIR/"checkpoints/galaxai_model1_v2_best.pth"},
    "Model 2 — ResNet-18": {
        "architecture":"ImageNet-pretrained ResNet-18", "description":"ResNet-18 backbone (512 features), shared 256-unit head, and 10 task-specific prediction heads.",
        "metrics":[BASE_DIR/"models/model2_resnet/results/test_metrics.json", BASE_DIR/"results/model2_resnet/test_metrics.json"],
        "heatmaps":BASE_DIR/"models/model2_resnet/results", "best_epoch":2, "parameters":"Not recorded here",
        "checkpoint":BASE_DIR/"models/model2_resnet/checkpoints/galaxai_model2_resnet18_best.pth"},
    "Model 3 — MobileNetV3-Large": {
        "architecture":"ImageNet-pretrained MobileNetV3-Large", "description":"MobileNetV3-Large backbone (960 features), shared 256-unit head, and 10 task-specific prediction heads.",
        "metrics":[BASE_DIR/"models/model3_mobilenet/results/test_metrics.json", BASE_DIR/"results/model3_mobilenet/results/test_metrics.json"],
        "heatmaps":BASE_DIR/"models/model3_mobilenet/results", "best_epoch":3, "parameters":"3,221,823",
        "checkpoint":BASE_DIR/"models/model3_mobilenet/checkpoints/galaxai_model3_mobilenetv3_large_best.pth"},
}

@st.cache_data(show_spinner=False)
def read_json(path):
    try:
        with Path(path).open(encoding="utf-8") as f:
            value = json.load(f)
        return value if isinstance(value, dict) else None
    except (OSError, json.JSONDecodeError):
        return None

def load_metrics(name):
    for path in MODELS[name]["metrics"]:
        if path.is_file():
            return read_json(str(path)), path
    return None, None

def fmt(value, percent=False):
    try:
        number = float(value)
        return f"{number*100:.2f}%" if percent else f"{number:.4f}"
    except (TypeError, ValueError):
        return "—"

def summary(data):
    return data.get("summary", {}) if data else {}

def metric_for(record, key):
    aliases = {
        "F1 / Macro F1": ("f1", "macro_f1"),
        "Accuracy": ("accuracy",),
        "Balanced accuracy": ("balanced_accuracy",),
        "Precision": ("precision", "macro_precision"),
        "Recall": ("recall", "macro_recall"),
        "ROC-AUC": ("roc_auc",),
        "PR-AUC / AP": ("pr_auc", "average_precision"),
    }
    for candidate in aliases[key]:
        if candidate in record and record[candidate] is not None:
            return record[candidate]
    return None

def render_task_table(data, group):
    tasks = data.get(group, {}) if data else {}
    if not tasks:
        st.warning(f"No {group} metrics found in this JSON.")
        return
    rows = []
    for task in TASKS:
        if task not in tasks:
            continue
        m = tasks[task]
        row = {"Task": LABELS.get(task, task), "Valid samples": m.get("samples", "—")}
        if group == "binary":
            keys = [("Accuracy","accuracy"),("Balanced accuracy","balanced_accuracy"),
                    ("Precision","precision"),("Recall","recall"),("F1","f1"),
                    ("ROC-AUC","roc_auc"),("PR-AUC / AP","pr_auc")]
        else:
            keys = [("Accuracy","accuracy"),("Balanced accuracy","balanced_accuracy"),
                    ("Macro precision","macro_precision"),("Macro recall","macro_recall"),
                    ("Macro F1","macro_f1")]
            if isinstance(m.get("per_class_f1"), list):
                row["Per-class F1"] = ", ".join(fmt(x) for x in m["per_class_f1"])
        for label, key in keys:
            row[label] = fmt(m.get(key))
        rows.append(row)
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

def render_confusion(name, data):
    config = MODELS[name]
    records = {}
    for group in ("binary", "multiclass"):
        if isinstance(data.get(group), dict):
            records.update(data[group])
    st.caption("All available task confusion matrices and saved heatmaps are shown below.")
    found_any = False
    for task in TASKS:
        if task not in records:
            continue
        record = records[task]
        cm = record.get("confusion_matrix")
        image_files = list(config["heatmaps"].glob("*.png")) if config["heatmaps"].is_dir() else []
        matching = [p for p in image_files if task.lower() in p.stem.lower()]
        with st.expander(LABELS.get(task, task), expanded=False):
            if isinstance(cm, list):
                labels = ["Negative", "Positive"] if task in BINARY else CLASSES.get(task, [str(i) for i in range(len(cm))])
                st.write("Confusion matrix (rows = true labels; columns = predicted labels)")
                st.dataframe(pd.DataFrame(cm, index=labels[:len(cm)], columns=labels[:len(cm[0])]), use_container_width=True)
                found_any = True
            if matching:
                st.image(str(matching[0]), caption=f"{LABELS.get(task, task)} confusion-matrix heatmap", use_container_width=True)
                found_any = True
            if not isinstance(cm, list) and not matching:
                st.info("No confusion-matrix values or saved heatmap were found for this task.")
    if not found_any:
        st.info("No confusion matrices were found in this model's evaluation JSON or results folder.")


def render_loss_history(name):
    config = MODELS[name]
    key = name.split("—")[0].strip().lower().replace(" ", "")
    history_candidates = []
    if key == "model1":
        history_candidates = [BASE_DIR/"results/model1_v2_history.json",
                              BASE_DIR/"models/model1_custom_cnn/results/history.json",
                              BASE_DIR/"models/model1_custom_cnn/results/model1_v2_history.json"]
    elif key == "model2":
        history_candidates = [BASE_DIR/"models/model2_resnet/results/model2_resnet18_history.json",
                              BASE_DIR/"models/model2_resnet/results/history.json"]
    elif key == "model3":
        history_candidates = [BASE_DIR/"models/model3_mobilenet/results/model3_mobilenetv3_large_history.json",
                              BASE_DIR/"models/model3_mobilenet/results/history.json"]
    history = None
    history_path = None
    for candidate in history_candidates:
        if candidate.is_file():
            history = read_json(str(candidate))
            if history is not None:
                history_path = candidate
                break
    if history is None:
        st.info("No recognized training-history JSON was found for this model. Loss plots are shown when the history file is available.")
        return
    rows = history.get("history", history.get("epochs", history.get("records", history)))
    if isinstance(rows, dict):
        # Some logs store metric series as parallel lists.
        keys = [k for k, v in rows.items() if isinstance(v, list)]
        if keys and all(isinstance(rows[k], list) for k in keys):
            length = max(len(rows[k]) for k in keys)
            frame = pd.DataFrame({k: rows[k] for k in keys if len(rows[k]) == length})
        else:
            st.json(history)
            return
    elif isinstance(rows, list) and rows and all(isinstance(row, dict) for row in rows):
        frame = pd.DataFrame(rows)
    else:
        st.json(history)
        return
    frame.columns = [str(c).lower() for c in frame.columns]
    epoch_col = next((c for c in frame.columns if c in ("epoch", "epochs")), None)
    train_col = next((c for c in frame.columns if "train" in c and "loss" in c and "task" not in c), None)
    val_col = next((c for c in frame.columns if ("val" in c or "valid" in c) and "loss" in c and "task" not in c), None)
    if epoch_col is not None:
        frame = frame.set_index(epoch_col)
    if train_col or val_col:
        chart_cols = [c for c in (train_col, val_col) if c and c in frame.columns]
        chart = frame[chart_cols].apply(pd.to_numeric, errors="coerce")
        chart.columns = [("Training loss" if "train" in c else "Validation loss") for c in chart.columns]
        st.line_chart(chart, use_container_width=True)
    else:
        st.caption("The history file was found, but its column names do not clearly identify train/validation loss.")
    st.caption(f"Training history source: {history_path}")
    st.dataframe(frame.reset_index(), use_container_width=True, hide_index=True)

def comparison_page():
    st.header("Three-model evaluation comparison")
    st.caption("Metrics are read from each model's saved test_metrics.json. No model is retrained by this dashboard.")
    loaded = {name: load_metrics(name) for name in MODELS}
    rows = []
    for name, (data, path) in loaded.items():
        s = summary(data)
        correct, valid = s.get("overall_correct_predictions"), s.get("overall_valid_predictions")
        rows.append({
            "Model":name, "Architecture":MODELS[name]["architecture"],
            "Pooled task accuracy":s.get("overall_accuracy", s.get("pooled_accuracy")),
            "Binary macro F1":s.get("binary_macro_f1"),
            "Multiclass macro F1":s.get("multiclass_macro_f1"),
            "Overall macro task F1":s.get("overall_macro_task_f1"),
            "Correct / valid predictions":f"{correct:,} / {valid:,}" if isinstance(correct,int) and isinstance(valid,int) else "—",
            "Metrics file":str(path) if path else "NOT FOUND",
        })
    st.subheader("Headline metrics")
    df = pd.DataFrame(rows)
    show = df.copy()
    for col in ["Pooled task accuracy","Binary macro F1","Multiclass macro F1","Overall macro task F1"]:
        show[col] = show[col].map(fmt)
    st.dataframe(show, use_container_width=True, hide_index=True)
    st.caption("Pooled task accuracy aggregates valid predictions across separate tasks; it is not the same as macro task F1 or conventional single-label image accuracy.")
    scored = [r for r in rows if isinstance(r["Overall macro task F1"], (int,float))]
    if scored:
        best = max(scored, key=lambda r:r["Overall macro task F1"])
        st.success(f"Highest overall macro task F1 in available JSON files: {best['Model']} ({best['Overall macro task F1']:.4f}).")

    st.subheader("Per-task comparison")
    metric = st.selectbox("Metric", ["F1 / Macro F1","Accuracy","Balanced accuracy","Precision","Recall","ROC-AUC","PR-AUC / AP"])
    chart_rows = []
    for task in TASKS:
        row = {"Task":LABELS[task]}
        group = "binary" if task in BINARY else "multiclass"
        for name, (data, _) in loaded.items():
            record = (data or {}).get(group, {}).get(task, {})
            row[name] = metric_for(record, metric)
        chart_rows.append(row)
    chart = pd.DataFrame(chart_rows).set_index("Task")
    st.bar_chart(chart, use_container_width=True)
    table = chart.reset_index()
    for name in MODELS:
        table[name] = table[name].map(fmt)
    st.dataframe(table, use_container_width=True, hide_index=True)

    st.subheader("All evaluation metrics")
    selected = st.selectbox("Model detail", list(MODELS), key="detail_model")
    data, path = loaded[selected]
    if data is None:
        st.error("Metrics JSON not found. Expected one of:\n" + "\n".join(str(p) for p in MODELS[selected]["metrics"]))
    else:
        tabs = st.tabs(["8 binary tasks","2 multiclass tasks","Confusion matrices","Training history","Architecture & files"])
        with tabs[0]:
            render_task_table(data, "binary")
        with tabs[1]:
            render_task_table(data, "multiclass")
        with tabs[2]:
            render_confusion(selected, data)
        with tabs[3]:
            render_loss_history(selected)
        with tabs[4]:
            config = MODELS[selected]
            st.markdown(f"**{config['architecture']}**")
            st.write(config["description"])
            st.write(f"Recorded best epoch: {config['best_epoch']}")
            st.write(f"Parameter count: {config['parameters']}")
            st.write(f"Checkpoint exists locally: {'Yes' if config['checkpoint'].is_file() else 'No / not included locally'}")
            st.code(str(path))
    with st.expander("Metric guide"):
        st.markdown("""
- **Precision:** proportion of predicted positives that are correct.
- **Recall:** proportion of actual positives detected.
- **F1:** harmonic mean of precision and recall.
- **Balanced accuracy:** average class recall, useful with imbalanced labels.
- **ROC-AUC:** ability to rank positives above negatives across thresholds.
- **PR-AUC / average precision:** particularly useful for rare positive classes.
- **Macro F1:** gives each class or task equal weight rather than letting common labels dominate.
- **Confusion matrix:** shows false positives and false negatives that a headline metric can hide.
""")
    st.warning("For a strict architecture-only comparison, verify the three evaluation JSONs use the same test split and metric definitions. Rare attributes such as disturbed, bar and merger should be judged using precision, recall, F1, PR-AUC and confusion matrices—not accuracy alone.")

def overview_page():
    st.header("Research overview")
    a,b,c = st.columns(3)
    a.metric("Architectures","3")
    b.metric("Morphology tasks","10")
    c.metric("Output logits","15")
    st.markdown("""
**Research question:** How effectively can different CNN architectures learn multiple morphological attributes from Hubble Space Telescope galaxy images, and how do architectural differences affect recognition of common and rare morphological features?

**Dataset:** Galaxy Zoo: Hubble. The project uses a 70/15/15 train-validation-test split (`random_state=42`) and task-specific masks for unavailable or ambiguous annotations.

- **8 binary tasks:** featured, edge-on, bar, spiral arms, disturbed, merger, clumpy and symmetry.
- **2 multiclass tasks:** bulge prominence (4 classes) and roundedness (3 classes).
- **15 logits total:** one logit for each binary task, four bulge logits and three roundedness logits.
""")
    for name, config in MODELS.items():
        with st.expander(name):
            st.markdown(f"**{config['architecture']}**")
            st.write(config["description"])
            st.write(f"Recorded best epoch: {config['best_epoch']} · Parameters: {config['parameters']}")
    st.info("Model 1 remains the frozen baseline. This app reads existing results and does not modify checkpoints or retrain models.")

def inference_page():
    st.header("Live galaxy image inference")
    st.write("Uses the existing `src/inference.py` inference pipeline.")
    try:
        from inference import load_model, predict, model_info
    except Exception as exc:
        st.error("Could not import the existing inference pipeline.")
        st.code(str(exc))
        st.info("The comparison dashboard still works without inference. Check `src/inference.py` and the Model 1 checkpoint.")
        return
    uploaded = st.file_uploader("Upload galaxy image", type=["jpg","jpeg","png","webp","tif","tiff"])
    if uploaded is None:
        st.info("Choose an image to begin.")
        return
    try:
        image = Image.open(uploaded).convert("RGB")
    except Exception as exc:
        st.error(f"Could not open image: {exc}")
        return
    left, right = st.columns([1,1])
    with left:
        st.image(image, caption=f"{image.width} × {image.height} pixels", use_container_width=True)
    with right:
        try:
            st.write("Inference model information")
            st.json(model_info())
        except Exception:
            pass
        if st.button("🚀 Analyze galaxy", type="primary", use_container_width=True):
            try:
                with st.spinner("Analyzing morphology…"):
                    model = load_model()
                    st.session_state["galaxai_result"] = predict(image, model)
            except Exception as exc:
                st.error("Inference failed; inspect the existing inference module API and checkpoint path.")
                st.exception(exc)
    result = st.session_state.get("galaxai_result")
    if isinstance(result, dict):
        st.subheader("Morphology profile")
        st.caption("Scores are model outputs, not calibrated probabilities unless calibration was performed.")
        cols = st.columns(4)
        for i, task in enumerate(BINARY):
            item = result.get(task, {})
            if not isinstance(item, dict):
                continue
            with cols[i % 4]:
                st.metric(LABELS[task], fmt(item.get("score"), percent=True))
                if item.get("detected") is not None:
                    st.caption("Detected" if item["detected"] else "Not detected")
        cols = st.columns(2)
        for i, task in enumerate(MULTI):
            item = result.get(task, {})
            if isinstance(item, dict):
                with cols[i]:
                    st.markdown(f"**{LABELS[task]}**")
                    st.write(item.get("label", item.get("class_name", "Prediction available")))
                    if item.get("score") is not None:
                        st.caption(f"Model score: {fmt(item['score'])}")

page = st.sidebar.radio("Navigation", ["Research overview","Live image inference","Three-model comparison"])
if page == "Research overview":
    overview_page()
elif page == "Live image inference":
    inference_page()
else:
    comparison_page()

st.divider()
st.caption("GALAXAI research prototype · Inspect per-task metrics and confusion matrices, especially for rare morphology attributes.")
